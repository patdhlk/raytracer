package main

import "image/color"
import "math"

type Plane struct {
	normalLocation  Vector
	normalDirection Vector
	color           color.RGBA
}

/**
 * RayIntersection
 *
 * Calculates, if there is a intersection between ray and plane.
 *
 * @param ray Ray to intersect with plane
 * @return float64 Distance of intersection
 * @return Ray Reflected ray
 * @return color.RGBA Color of intersection point on the plane
 * @return bool True if there is a intersection
 */
func (this Plane) RayIntersection(ray Ray) (float64, Ray, color.RGBA, bool) {
	/*
		Calculate intersection using formula:
		t = ((E-a)N)/(bN)

		E = Point where normal on plane starts
		N = Normal on plane with length 1
		b = direction of ray
		a = origin of ray
	*/

	bDotN := ray.direction.DotProduct(this.normalDirection)    //Solution of bN
	eMinusA := ray.origin.MinusTwoVectors(this.normalLocation) //Solution of (E-a)
	eMinusAN := eMinusA.DotProduct(this.normalDirection)       //Solution of (E-a)N
	var intersectionDistance float64 = eMinusAN / bDotN

	if intersectionDistance < 0 {
		return 0, ray, color.RGBA{0, 0, 0, 0}, false
	}

	reflectionRay, locationOfIntersection := this.CalculateReflectionRay(ray, intersectionDistance)

	//Create chessboard by inverting plane color if x and y are both eval or odd
	chessboardVector := locationOfIntersection.MinusTwoVectors(this.normalLocation)

	var returnColor color.RGBA = this.color
	if math.Abs(math.Mod(float64(int(chessboardVector.x)), 2)) == 0 && math.Abs(math.Mod(float64(int(chessboardVector.y*correctionOfSquareChessboard)), 2)) == 0 || math.Abs(math.Mod(float64(int(chessboardVector.x)), 2)) == 1 && math.Abs(math.Mod(float64(int(chessboardVector.y*correctionOfSquareChessboard)), 2)) == 1 {
		returnColor = color.RGBA{uint8(255 - this.color.R), uint8(255 - this.color.G), uint8(255 - this.color.B), uint8(255 - this.color.A)}
	}

	return intersectionDistance, reflectionRay, returnColor, true
}

/**
 * CalculateReflectionRay
 *
 * Calculates the reflected ray
 *
 * @param ray Ray to intersect with plane
 * @param intersectionDistance Distance of intersection
 * @return Ray Reflected ray
 */
func (this Plane) CalculateReflectionRay(ray Ray, intersectionDistance float64) (Ray, Vector) {
	/*
		Calculating reflection ray
		direction: V=b-2(bN)N
		b = r.direction
		N = normale = locationOfIntersection-location of plane
		origin: locationOfIntersection
	*/
	locationOfIntersection := ray.origin.PlusTwoVectors(ray.direction.MultiplyWithScalar(intersectionDistance))

	bN := ray.direction.DotProduct(this.normalDirection)
	directionOfReflectionRay := ray.direction.MinusTwoVectors(this.normalDirection.MultiplyWithScalar(2 * bN))

	return NewRay(locationOfIntersection, directionOfReflectionRay), locationOfIntersection
}

/**
 * NewPlane
 *
 * Creates a plane
 *
 * @param xLocation X location of new plane
 * @param yLocation Y location of new plane
 * @param zLocation Z location of new plane
 * @param xDirection X location of new plane
 * @param yDirection Y location of new plane
 * @param zDirection Z location of new plane
 * @param color Color of new plane
 * @return Plane Returns new created plane
 */
func NewPlane(xLocation float64, yLocation float64, zLocation float64, xDirectionNormal float64, yDirectionNormal float64, zDirectionNormal float64, Color color.RGBA) Plane {
	normalDirection := Vector{xDirectionNormal, yDirectionNormal, zDirectionNormal}
	normalDirection.Normalize()

	p := Plane{Vector{xLocation, yLocation, zLocation}, normalDirection, Color}
	return p
}
