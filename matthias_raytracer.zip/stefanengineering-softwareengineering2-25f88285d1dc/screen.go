package main

import "image"

type Screen struct {
	height int
	width  int
	image  *image.RGBA
}

/**
 * NewScreen
 *
 * Creates a new screen.
 * The position x=0 and y=0 in the screen, is in the left bottom corner
 *
 * @param xSize X size of screen
 * @param ySize Y size o screen
 * @return *Screen Returns new created screen
 */
func NewScreen(xSize int, ySize int) *Screen {
	scr := Screen{ySize, xSize, image.NewRGBA(image.Rectangle{Min: image.Point{0, 0}, Max: image.Point{xSize, ySize}})}
	return &scr
}
