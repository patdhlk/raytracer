package main

import "image/color"
import "math"

type Ball struct {
	radius   float64
	location Vector
	color    color.RGBA
}

/**
 * RayIntersection
 *
 * Calculates, if there is a intersection between ray and ball.
 *
 * @param ray Ray to intersect with ball
 * @return float64 Distance of intersection
 * @return Ray Reflected ray
 * @return color.RGBA Color of intersection point on the ball
 * @return bool True if there is a intersection
 */
func (this Ball) RayIntersection(ray Ray) (float64, Ray, color.RGBA, bool) {
	/*
		Calculate Intersection using formula:
		t1,2 = -db +- sqrt((db)²+R²-d²)

		a = origin of ray
		b = direction of ray
		R = radius of ball
		k = location of ball
		d = a-k
	*/

	d := ray.origin.MinusTwoVectors(this.location)

	dDotB := d.DotProduct(ray.direction) //Solution from db
	inSqrtPart := dDotB*dDotB + this.radius*this.radius - d.DotProduct(d)

	if inSqrtPart < 0 { //Value in square root negativ -> No intersection with ball
		return 0, ray, color.RGBA{0, 0, 0, 0}, false
	}

	t1 := -dDotB + math.Sqrt(inSqrtPart)
	t2 := -dDotB - math.Sqrt(inSqrtPart)

	//Getting nearest of 2 possible intersections
	var intersectionDistance float64

	if t1 < 0 {
		intersectionDistance = t2
	} else {
		if t2 < 0 {
			intersectionDistance = t1
		} else {
			if t1 < t2 {
				intersectionDistance = t1
			} else {
				intersectionDistance = t2
			}
		}
	}

	reflectionRay := this.CalculateReflectionRay(ray, intersectionDistance)

	//Berechne Beleuchtung mit phong modell

	return intersectionDistance, reflectionRay, this.color, true
}

/**
 * CalculateReflectionRay
 *
 * Calculates the reflected ray
 *
 * @param ray Ray to intersect with ball
 * @param intersectionDistance Distance of intersection
 * @return Ray Reflected ray
 */
func (this Ball) CalculateReflectionRay(ray Ray, intersectionDistance float64) Ray {
	/*
		Calculating reflection ray
		direction: V=b-2(bN)N
		b = r.direction
		N = normale = locationOfIntersection-location of ball
		origin: locationOfIntersection
	*/
	locationOfIntersection := ray.origin.PlusTwoVectors(ray.direction.MultiplyWithScalar(intersectionDistance))

	normal := locationOfIntersection.MinusTwoVectors(this.location)
	//normal = Vector{-normal.x, -normal.y, normal.z} //Adjust x and y of normal

	bN := ray.direction.DotProduct(normal)
	directionOfReflectionRay := ray.direction.MinusTwoVectors(normal.MultiplyWithScalar(2 * bN))
	return NewRay(locationOfIntersection, directionOfReflectionRay)
}

/**
 * NewBall
 *
 * Creates a ball.
 *
 * @param x X location of new ball
 * @param y Y location of new ball
 * @param z Z location of new ball
 * @param radius Radius of new ball
 * @param color Color of new ball
 * @return Ball Returns new created ball
 */
func NewBall(x float64, y float64, z float64, radius float64, color color.RGBA) Ball {
	b := Ball{radius, Vector{x, y, z}, color}
	return b
}
