package main

import "math"

type Vector struct {
	x float64
	y float64
	z float64
}

func (this Vector) MultiplyWithScalar(m float64) Vector { //Returns new value
	return Vector{this.x * m, this.y * m, this.z * m}
}
func (this Vector) PlusTwoVectors(v Vector) Vector { //Returns new value
	return Vector{this.x + v.x, this.y + v.y, this.z + v.z}
}
func (this Vector) MinusTwoVectors(v Vector) Vector { //Returns new value
	return Vector{this.x - v.x, this.y - v.y, this.z - v.z}
}

func (this *Vector) Normalize() { //Modifies local variables
	n := this.Value()
	this.x *= 1 / n
	this.y *= 1 / n
	this.z *= 1 / n
}

//Skalarprodukt bzw. inneres Produkt
func (this Vector) DotProduct(v Vector) float64 { //Returns new value
	return this.x*v.x + this.y*v.y + this.z*v.z
}

//Betrag des Vectors
func (this Vector) Value() float64 { //Returns new value
	return math.Sqrt(this.x*this.x + this.y*this.y + this.z*this.z)
}

//Kreuzprodukt bzw. Vektorprodukt bzw. äußeres Produkt
func (this Vector) CrossProduct(v Vector) Vector { // Returns new value
	return Vector{this.y*v.z - this.z*v.y, this.z*v.x - v.x*this.z, this.x*v.y - this.y*v.x}
}
