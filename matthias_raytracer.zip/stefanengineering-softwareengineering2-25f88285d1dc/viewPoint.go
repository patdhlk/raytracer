package main

type ViewPoint struct {
	Point Vector
}

/**
 * ViewPoint
 *
 * Creates a ray from the viewpoint trough screen with shift depending on x and y
 * x is the x axis, positiv is right
 * y is the y axis, positiv is up
 * In the screen the viewpoint is in the middle of the screen. That means
 * if you have a screen size of 800x600, the direction Vector of the
 * created ray is 0,0,0 at the pixel x=400 and y=300
 *
 * @param x X position in screen
 * @param y Y position in screen
 * @return Ray Returnes created ray
 */
func (this ViewPoint) CreateRayFromViewPointThroughScreen(x int, y int) Ray {
	//Moves the viewpoint to the middle of the screen
	x = x - screen.width/2
	y = y - screen.height/2

	r := NewRay(this.Point, Vector{float64(x) / openingAngleOfCamera, float64(y) / openingAngleOfCamera, 10})
	return r
}
