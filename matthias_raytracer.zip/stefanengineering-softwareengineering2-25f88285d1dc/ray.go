package main

type Ray struct {
	origin    Vector
	direction Vector
}

/**
 * NewRay
 *
 * Creates a ray.
 *
 * @param origin Origin of new ray
 * @param direction Direction of new ray
 * @return Ray Returns new created ray
 */
func NewRay(origin Vector, direction Vector) Ray {
	direction.Normalize()
	ray := Ray{origin, direction}
	return ray
}
