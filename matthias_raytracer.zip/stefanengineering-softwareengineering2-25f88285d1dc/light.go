package main

type Light struct {
	position Vector
}
