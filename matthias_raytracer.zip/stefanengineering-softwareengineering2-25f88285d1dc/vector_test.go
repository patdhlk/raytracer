package main

import "testing"

import "math"

func TestMultiplyWithScalar(t *testing.T) {
	v := Vector{1, 1, 1}
	vResult := v.MultiplyWithScalar(2)
	if vResult.x != 2 || vResult.y != 2 || vResult.z != 2 {
		t.Fail()
	}
}
func TestPlusTwoVectors(t *testing.T) {
	v1 := Vector{1, 1, 1}
	v2 := Vector{1, 1, 1}
	v := Vector{v1.x + v2.x, v1.y + v2.y, v1.z + v2.z}

	if v.x != 2 || v.y != 2 || v.z != 2 {
		t.Fail()
	}
}
func TestMinusTwoVectors(t *testing.T) {
	v1 := Vector{1, 1, 1}
	v2 := Vector{1, 1, 1}
	v := Vector{v1.x - v2.x, v1.y - v2.y, v1.z - v2.z}

	if v.x != 0 || v.y != 0 || v.z != 0 {
		t.Fail()
	}
}
func TestNormalize(t *testing.T) {
	v := Vector{1, 1, 1}
	v.Normalize()
	if v.x < 0.577 || v.x > 0.578 || v.y < 0.577 || v.y > 0.578 || v.z < 0.577 || v.z > 0.578 {
		t.Fail()
	}
}
func TestDotProduct(t *testing.T) {
	v1 := Vector{1, 1, 1}
	v2 := Vector{1, 1, 1}
	if v1.DotProduct(v2) != 3 {
		t.Fail()
	}
}
func TestValue(t *testing.T) {
	v := Vector{math.Sqrt(3), math.Sqrt(3), math.Sqrt(3)}
	if v.Value() < 2.99 || v.Value() > 3.01 {
		t.Fail()
	}
}
func TestCrossProduct(t *testing.T) {
	v1 := Vector{1, 1, 1}
	v2 := Vector{1, 1, 1}
	v := Vector{v1.y*v2.z - v1.z*v2.y, v1.z*v2.x - v1.x*v2.z, v1.x*v2.y - v1.y*v2.x}

	if v.x != 0 || v.y != 0 || v.z != 0 {
		t.Fail()
	}
}
